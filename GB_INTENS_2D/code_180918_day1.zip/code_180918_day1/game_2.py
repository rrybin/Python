import os
import tkinter

IMG_DIR = 'nums'

files_names = sorted(os.listdir(IMG_DIR))

files_pathes = []
for file_name in files_names:
    file_path = os.path.join(IMG_DIR, file_name)
    files_pathes.append(file_path)

# print(files_pathes)


main_window = tkinter.Tk()
main_window.title('игра 15')

images = []
for file_path in files_pathes:
    image = tkinter.PhotoImage(file=file_path)
    # print(image)
    images.append(image)

labels = []
for image in images:
    # print(image)
    # label = tkinter.Label(main_window, text='hello')
    label = tkinter.Label(main_window, image=image)
    label.grid()
    labels.append(label)


print(labels)

main_window.mainloop()

# while True:
#     pass
