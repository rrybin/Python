a = [14, 'hello', True, 19.5]

a[1] = 999
# print(a)

# print(a)
# print(dir(a))
#
# print(a[-1])
# print(a[len(a) - 1])

b = (14, 'hello', True, 19.5)

# print(type(b))
# print(dir(b))

# b[1] = 888
# print(b)

print(a, b)

a, b = b, a
# (a, b) = (b, a)
ALPHA = (15, )

print(a, b)

print(help(list))

