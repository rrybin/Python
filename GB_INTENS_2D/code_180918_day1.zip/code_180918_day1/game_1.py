import os

IMG_DIR = 'nums'

files_names = os.listdir(IMG_DIR)
# r'nums\01.gif'

files_pathes = []

for file_name in files_names:
    # file_path = f'{IMG_DIR}/{file_name}'
    file_path = os.path.join(IMG_DIR, file_name)
    # print(file_path)
    files_pathes.append(file_path)


images = []

print(files_pathes)


