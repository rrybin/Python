a = [14, 'hello', True, 19.5]

print(a)
print(type(a))

b = 15.5

print(type(b))

b = 'world'
print(type(b))


