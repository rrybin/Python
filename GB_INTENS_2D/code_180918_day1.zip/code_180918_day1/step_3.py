# salary = [
#     ['Иванов Е.С.', 7461.58, 8487.61, 8143.43, 7896.41, 5921.96, 7295.52],
#     ['Андреев И.В.', 6548.97, 7951.47, 7259.54, 8053.5, 7891.67, 7317.24],
#     ['Петров А.И.', 5258.5, 6124.87, 3528.97, 5957.54, 4978.54, 6157.41],
# ]

worker_1 = ['Иванов Е.С.', 7461.58, 8487.61, 8143.43, 7896.41, 5921.96, 7295.52]
worker_2 = ['Андреев И.В.', 6548.97, 7951.47, 7259.54, 8053.5, 7891.67, 7317.24]
worker_3 = ['Петров А.И.', 5258.5, 6124.87, 3528.97, 5957.54, 4978.54, 6157.41]

# salary = [worker_1, worker_2, worker_3]

workers_zip = list(zip(worker_1, worker_2, worker_3))
# ('Иванов Е.С.', 'Андреев И.В.', 'Петров А.И.')
# workers = workers_zip.pop(0)
workers_zip.pop(0)

# print(workers)
# print(len(workers_zip))

# print(workers_zip)

for _item in workers_zip:
    salary = sum(_item)
    salary_avg = salary / len(_item)
    # print(salary_avg)
    print(f'средняя зарплата за месяц: {salary_avg:.2f}')
    # print(_item)

