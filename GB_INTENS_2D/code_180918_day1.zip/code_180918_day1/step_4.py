salary = [
    ['Иванов Е.С.', 7461.58, 8487.61, 8143.43, 7896.41, 5921.96, 7295.52],
    ['Андреев И.В.', 6548.97, 7951.47, 7259.54, 8053.5, 7891.67, 7317.24],
    ['Петров А.И.', 5258.5, 6124.87, 3528.97, 5957.54, 4978.54, 6157.41],
]

months = ['январь', 'февраль', 'март', 'апрель', 'май', 'июнь']
months_iterator = iter(months)


# worker_1 = ['Иванов Е.С.', 7461.58, 8487.61, 8143.43, 7896.41, 5921.96, 7295.52]
# worker_2 = ['Андреев И.В.', 6548.97, 7951.47, 7259.54, 8053.5, 7891.67, 7317.24]
# worker_3 = ['Петров А.И.', 5258.5, 6124.87, 3528.97, 5957.54, 4978.54, 6157.41]
#
# salary = [worker_1, worker_2, worker_3]

workers_zip = list(zip(*salary))
workers_zip.pop(0)

# for idx, _item in enumerate(workers_zip):
#     salary = sum(_item)
#     salary_avg = salary / len(_item)
#     # print(f'индекс месяца: {idx}')
#     out_text = f'средняя зарплата за {months[idx]:8}: {salary_avg:.2f}'
#     print(out_text)

if len(months) != len(workers_zip):
    print('ошибка исходных данных!')
    exit(1)

for _item in workers_zip:
    salary = sum(_item)
    salary_avg = salary / len(_item)
    out_text = f'средняя зарплата за {next(months_iterator):8}: {salary_avg:.2f}'
    print(out_text)



